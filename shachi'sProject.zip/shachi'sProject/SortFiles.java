package com.sort;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/*
 * This class sorts the rows in the first file based on particular column passed
 * 
 * 
 */
public class SortFiles {

	private String file1;
	private String file2;

	SortFiles(String file1, String file2) {
		this.setFile1(file1);
		this.setFile2(file2);
	}

	public static void main(String args[]) {
		char coulmnFile1 = 'b';
		char columnFile2 = 'd';
		String file1 = "c://File1.xlsx";
		String file2 = "c://File2.xlsx";
		Map<Integer, Row> toBeSorted = null;

		SortFiles sortFiles = new SortFiles(file1, file2);
		try {
			toBeSorted = sortFiles.populateMapWithCSVFileRows(file1, file2, coulmnFile1, columnFile2);

		} catch (IOException e) {
			e.printStackTrace();
		}
		sortFiles.printValues(toBeSorted);
	}

	private Map<Integer, Row> populateMapWithCSVFileRows(String csvFile1, String csvfile2, char firstFileColumntoSort,
			char secondFileColumn) throws IOException {

		File fileToBeSort = null;
		Map<Integer, Row> sheetRows = new HashMap<Integer, Row>();
		XSSFWorkbook workbook = null;
		try {
			workbook = new XSSFWorkbook(fileToBeSort);
			Sheet datatypeSheet = workbook.getSheetAt(0);
			Iterator<Row> rowiIerator = datatypeSheet.iterator();
			int index = 0;
			Row currentRow;

			while (rowiIerator.hasNext()) {
				currentRow = rowiIerator.next();
				sheetRows.put(index, currentRow);
				index = index + 1;
			}
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sheetRows;
	}

	private void printValues(Map<Integer, Row> sheetRows) {

		System.out.println("a,b,c");
		Row currentRow;
		Iterator<Cell> cellIterator;
		Cell currentCell;
		for (int i = sheetRows.size(); i > 0; i--) {
			currentRow = (Row) sheetRows.get(i);
			cellIterator = currentRow.iterator();

			while (cellIterator.hasNext()) {
				currentCell = cellIterator.next();
				if (currentCell.getCellTypeEnum() == CellType.NUMERIC) {
					System.out.print(currentCell.getNumericCellValue() + ",");
				}
			}
		}
	}

	public String getFile1() {
		return file1;
	}

	public void setFile1(String file1) {
		this.file1 = file1;
	}

	public String getFile2() {
		return file2;
	}

	public void setFile2(String file2) {
		this.file2 = file2;
	}
}
